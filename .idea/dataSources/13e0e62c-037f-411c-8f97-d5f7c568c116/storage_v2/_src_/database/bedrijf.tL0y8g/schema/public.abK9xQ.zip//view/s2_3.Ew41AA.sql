create view s2_3(resultaat) as
SELECT 'S2.3 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s2_3
    owner to postgres;


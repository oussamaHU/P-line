create view s2_7_test(snr) as
SELECT schalen.snr
FROM schalen;

alter table s2_7_test
    owner to postgres;


create view s3_1_test(code, begindatum, lengte, naam) as
SELECT answer.code,
       answer.begindatum,
       answer.lengte,
       answer.naam
FROM (VALUES ('S02'::character varying(4), '2019-04-12'::date, 4::numeric(2, 0), 'SPIJKER'::character varying(12)),
             ('OAG'::character varying, '2019-08-10'::date, 1, 'JANSEN'::character varying),
             ('S02'::character varying, '2019-10-04'::date, 4, 'SMIT'::character varying),
             ('S02'::character varying, '2019-12-13'::date, 4, 'SMIT'::character varying),
             ('JAV'::character varying, '2019-12-13'::date, 4, 'JANSEN'::character varying),
             ('XML'::character varying, '2020-02-03'::date, 2, 'SMIT'::character varying),
             ('JAV'::character varying, '2020-02-01'::date, 4, 'ADAMS'::character varying),
             ('PLS'::character varying, '2020-09-11'::date, 1, 'SCHOTTEN'::character varying),
             ('OAG'::character varying, '2020-09-27'::date, 1, 'SPIJKER'::character varying),
             ('RSO'::character varying, '2021-02-24'::date, 2,
              'SCHOTTEN'::character varying)) answer(code, begindatum, lengte, naam);

alter table s3_1_test
    owner to postgres;


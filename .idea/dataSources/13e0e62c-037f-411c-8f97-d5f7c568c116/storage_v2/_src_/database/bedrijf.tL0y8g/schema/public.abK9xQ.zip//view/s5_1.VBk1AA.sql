create view s5_1(cursist) as
SELECT i.cursist
FROM inschrijvingen i
WHERE i.cursus::text = 'JAV'::text
  AND (i.cursist IN (SELECT u.cursist
                     FROM inschrijvingen u
                     WHERE u.cursus::text = 'XML'::text));

alter table s5_1
    owner to postgres;


create view s3_3(afdeling, medewerker) as
SELECT a.naam AS afdeling,
       m.naam AS medewerker
FROM medewerkers m
         JOIN afdelingen a ON m.mnr = a.hoofd;

alter table s3_3
    owner to postgres;


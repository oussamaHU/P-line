create view s3_1(code, begindatum, lengte, naam) as
SELECT c.code,
       ui.begindatum,
       c.lengte,
       m.naam
FROM cursussen c,
     medewerkers m
         JOIN uitvoeringen ui ON m.mnr = ui.docent
WHERE c.code::text = ui.cursus::text;

alter table s3_1
    owner to postgres;


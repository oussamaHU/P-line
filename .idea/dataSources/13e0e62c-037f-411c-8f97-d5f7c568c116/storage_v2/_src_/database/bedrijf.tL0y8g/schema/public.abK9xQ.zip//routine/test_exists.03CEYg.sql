create function test_exists(_exercise_nr text, _row_test bigint, _compare_type text DEFAULT 'exact'::text) returns text
    language plpgsql
as
$$
DECLARE _sol_name TEXT := REPLACE(LOWER(_exercise_nr), '.', '_');
	DECLARE _test_name TEXT := _sol_name || '_test'; 
	DECLARE _row_count INT := 0;
    BEGIN
		EXECUTE FORMAT('SELECT COUNT(*) FROM %I;', _test_name) INTO _row_count;

        IF _compare_type = 'exact' AND _row_count = _row_test THEN
            RETURN _exercise_nr || ' heeft de juiste uitwerking op de database!';
        ELSIF _compare_type = 'maximaal' AND _row_count <= _row_test THEN
            RETURN _exercise_nr || ' heeft de juiste uitwerking op de database!';
        ELSIF _compare_type = 'minimaal' AND _row_count >= _row_test THEN
            RETURN _exercise_nr || ' heeft de juiste uitwerking op de database!';
        END IF;
        
        RETURN _exercise_nr || ' heeft niet de juiste uitwerking op de database: er moeten ' || _compare_type || ' ' || _row_test || ' rijen of kolommen zijn, maar de database heeft er ' || _row_count || '.';
    END;
$$;

alter function test_exists(text, bigint, text) owner to postgres;


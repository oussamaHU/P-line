create view s5_5(cursus, begindatum) as
SELECT uitvoeringen.cursus,
       uitvoeringen.begindatum
FROM uitvoeringen
WHERE date_part('year'::text, uitvoeringen.begindatum) = 2020::double precision
  AND (uitvoeringen.cursus::text IN (SELECT cursussen.code
                                     FROM cursussen
                                     WHERE cursussen.type = 'BLD'::bpchar));

alter table s5_5
    owner to postgres;


create view s5_3(mnr) as
SELECT m.mnr
FROM medewerkers m
WHERE NOT (m.mnr IN (SELECT inschrijvingen.cursist
                     FROM inschrijvingen
                     WHERE inschrijvingen.cursus::text = 'JAV'::text));

alter table s5_3
    owner to postgres;


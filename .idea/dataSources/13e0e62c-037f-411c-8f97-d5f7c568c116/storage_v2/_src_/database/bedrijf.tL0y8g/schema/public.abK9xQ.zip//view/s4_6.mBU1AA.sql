create view s4_6(resultaat) as
SELECT 'S4.6 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_6
    owner to postgres;


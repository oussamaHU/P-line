create view s4_3(code, begindatum, aantal_inschrijvingen) as
SELECT c.code,
       i.begindatum,
       count(i.cursus) AS aantal_inschrijvingen
FROM inschrijvingen i
         JOIN cursussen c ON c.code::text = i.cursus::text
WHERE date_part('year'::text, i.begindatum) = 2019::double precision
GROUP BY c.code, i.begindatum, i.cursus
HAVING count(*) >= 3;

alter table s4_3
    owner to postgres;


create view s3_2(cursist, docent) as
SELECT c.naam AS cursist,
       d.naam AS docent
FROM medewerkers c
         JOIN inschrijvingen ON inschrijvingen.cursist = c.mnr
         JOIN uitvoeringen ON inschrijvingen.cursus::text = uitvoeringen.cursus::text AND
                              inschrijvingen.begindatum = uitvoeringen.begindatum
         JOIN medewerkers d ON uitvoeringen.docent = d.mnr
WHERE inschrijvingen.cursus::text = 'S02'::text;

alter table s3_2
    owner to postgres;


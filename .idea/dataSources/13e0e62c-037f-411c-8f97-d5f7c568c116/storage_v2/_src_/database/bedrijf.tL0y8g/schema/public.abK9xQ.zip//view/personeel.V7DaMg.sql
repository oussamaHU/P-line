create view personeel(mnr, voorl, medewerker, afd, functie) as
SELECT medewerkers.mnr,
       medewerkers.voorl,
       medewerkers.naam AS medewerker,
       medewerkers.afd,
       medewerkers.functie
FROM medewerkers;

alter table personeel
    owner to postgres;


create view s5_6(aantal_inschrijvingen) as
SELECT count(cursussen.code) AS aantal_inschrijvingen
FROM cursussen
WHERE (cursussen.code::text IN (SELECT inschrijvingen.cursus
                                FROM inschrijvingen
                                ORDER BY inschrijvingen.begindatum));

alter table s5_6
    owner to postgres;


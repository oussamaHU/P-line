create view s5_4_test(naam) as
SELECT answer.naam
FROM (VALUES ('JANSEN'::character varying(12)),
             ('CLERCKX'::character varying),
             ('SCHOTTEN'::character varying),
             ('DE KONING'::character varying),
             ('SPIJKER'::character varying),
             ('BLAAK'::character varying)) answer(naam);

alter table s5_4_test
    owner to postgres;


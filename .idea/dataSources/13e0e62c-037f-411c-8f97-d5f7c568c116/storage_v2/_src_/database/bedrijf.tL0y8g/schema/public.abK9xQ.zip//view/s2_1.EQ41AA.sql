create view s2_1(resultaat) as
SELECT 'S2.1 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s2_1
    owner to postgres;


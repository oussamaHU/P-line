create view s5_2(mnr) as
SELECT m.mnr
FROM medewerkers m
WHERE NOT (m.afd IN (SELECT afdelingen.anr
                     FROM afdelingen
                     WHERE afdelingen.naam::text = 'OPLEIDINGEN'::text));

alter table s5_2
    owner to postgres;


create view s3_5(resultaat) as
SELECT 'S3.5 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s3_5
    owner to postgres;


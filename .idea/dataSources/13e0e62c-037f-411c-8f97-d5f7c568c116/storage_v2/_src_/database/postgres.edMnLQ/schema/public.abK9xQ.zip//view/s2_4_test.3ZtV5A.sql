create view s2_4_test(naam, voorl) as
SELECT medewerkers.naam,
       medewerkers.voorl
FROM medewerkers
WHERE medewerkers.mnr <> 7900::numeric;

alter table s2_4_test
    owner to postgres;


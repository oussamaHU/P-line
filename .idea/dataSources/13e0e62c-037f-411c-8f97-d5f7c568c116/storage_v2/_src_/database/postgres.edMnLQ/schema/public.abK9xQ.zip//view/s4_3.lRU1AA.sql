create view s4_3(resultaat) as
SELECT 'S4.3 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_3
    owner to postgres;


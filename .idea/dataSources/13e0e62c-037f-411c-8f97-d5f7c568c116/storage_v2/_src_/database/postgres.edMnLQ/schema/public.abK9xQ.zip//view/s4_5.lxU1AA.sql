create view s4_5(resultaat) as
SELECT 'S4.5 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_5
    owner to postgres;


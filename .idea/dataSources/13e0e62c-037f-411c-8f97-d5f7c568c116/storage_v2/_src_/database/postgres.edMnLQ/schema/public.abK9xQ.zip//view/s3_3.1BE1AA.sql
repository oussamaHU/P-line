create view s3_3(resultaat) as
SELECT 'S3.3 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s3_3
    owner to postgres;


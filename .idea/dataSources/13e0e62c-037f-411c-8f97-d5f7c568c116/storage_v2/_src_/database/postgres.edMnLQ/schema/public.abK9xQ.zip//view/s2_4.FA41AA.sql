create view s2_4(resultaat) as
SELECT 'S2.4 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s2_4
    owner to postgres;


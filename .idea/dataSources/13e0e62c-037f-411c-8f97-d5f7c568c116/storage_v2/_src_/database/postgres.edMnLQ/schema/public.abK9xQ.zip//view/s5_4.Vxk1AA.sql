create view s5_4(resultaat) as
SELECT 'S5.4 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_4
    owner to postgres;


create view s5_7_test(cursist, column2) as
SELECT answer.cursist,
       answer.column2
FROM (VALUES ('N'::character varying(5), 'SMIT'::character varying(12))) answer(cursist, column2);

alter table s5_7_test
    owner to postgres;


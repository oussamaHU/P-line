create view s3_1(resultaat) as
SELECT 'S3.1 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s3_1
    owner to postgres;


create view s5_2_test(mnr) as
SELECT answer.mnr
FROM (VALUES (7934::numeric(4, 0)), (7839), (7782), (7499), (7900), (7844), (7698), (7521), (7654)) answer(mnr);

alter table s5_2_test
    owner to postgres;


create view s3_4(resultaat) as
SELECT 'S3.4 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s3_4
    owner to postgres;


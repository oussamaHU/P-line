create view s5_6(resultaat) as
SELECT 'S5.6 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_6
    owner to postgres;


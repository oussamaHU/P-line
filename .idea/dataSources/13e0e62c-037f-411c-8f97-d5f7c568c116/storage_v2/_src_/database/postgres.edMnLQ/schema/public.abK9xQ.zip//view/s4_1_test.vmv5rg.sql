create view s4_1_test(mnr, functie, gbdatum) as
SELECT answer.mnr,
       answer.functie,
       answer.gbdatum
FROM (VALUES (7654::numeric(4, 0), 'VERKOPER'::character varying(10), '1976-09-28'::date),
             (7788, 'TRAINER'::character varying, '1979-11-26'::date),
             (7902, 'TRAINER'::character varying, '1979-02-13'::date)) answer(mnr, functie, gbdatum);

alter table s4_1_test
    owner to postgres;

